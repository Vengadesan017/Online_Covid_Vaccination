<?php
session_start();
?>

<?php
include_once "config.php";
try {

    if (isset($_POST["sign_up"])) {

            $username = $_POST["username"];
            $password = $_POST["password"];
            $email = $_POST["email"];
            $insert = $conn->prepare("INSERT INTO Users(username, password, email, login_id) VALUES(?,?,?,?)");
            $insert->execute([$username, password_hash($password, PASSWORD_DEFAULT), $email, 1]);

            $_SESSION['msg']="The new User ".$username." was successfuly created";
            header("Location: index.php");
    }

} catch (PDOException $e) {
    $_SESSION['error'] = $e->getMessage();
    header("Location: index.php");
}

$conn = null;
?>

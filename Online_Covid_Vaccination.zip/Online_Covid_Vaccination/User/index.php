<?php
  
  
    include_once "data.php";
  	if (isset($_SESSION['username']) && isset($_SESSION['user_id'])){
    
    $now = time();
      
        if($now > $_SESSION['expire']) {
            header("Location: ./../logout.php");  
        }
  }
  else {
    header("location: ./../index.php");
  }   
  $centers=display_center();

?>
<!DOCTYPE html>
<html>
<head>
  <title>Covid vaccination booking</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Covid vaccination booking</a>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link active" href="index.php">Centers</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo($_SESSION['username']); ?>
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="./../logout.php">Logout</a>
          </div>
        </li>
      </ul>
    </div>
  </nav>
  <?php
    if (isset($_SESSION['error'])) {
      echo " <div class='alert alert-danger alert-dismissible text-center mt-3'>
              ".$_SESSION['error']."<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a></div>
      ";
      unset($_SESSION['error']);
    }
    if (isset($_SESSION['msg'])) {
      echo " <div class='alert alert-success alert-dismissible text-center mt-3'>
              ".$_SESSION['msg']."<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a></div>";
      unset($_SESSION['msg']);
    }
  ?>

  <div class="container">

    <div class="container mt-5">

        <div class="row">
        	<div class="col-md-4">
  		   	 <button class="btn btn-info btn-add" data-toggle="modal" data-target="#new_center">Your Slot</button>
  			</div>
            <div class="col-md-4">

                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Search Center:</span>
                    </div>
                    <input type="search" class="form-control" placeholder="Search for..." onkeyup="search_by_name()" id="search_name">

                </div>
            </div>
            <div class="col-md-4">

                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Select Date:</span>
                    </div>
                    <input type="date" class="form-control" id='datePicker'>
                </div>
            </div>
        </div>
    </div>



  <div class="modal fade" id="new_center" role="dialog">
    <div class="modal-dialog">
    

      <div class="modal-content">
        <div class="modal-header">
          <h3>Your applied slot</h3>
          <button type="button" class="close" data-dismiss="modal">&times;</button>

        </div>
        <div class="modal-body">
	      <table class="table table-bordered">
	        <thead>
	          <tr>
	            <th>Center Name</th>
	            <th>Working Hour</th>
	            <th>Date</th>
	            <th>Location</th>


	          
	          </tr>
	        </thead>
	        <tbody>
	                 <?php foreach ($centers as $center): ?>
	                  <tr>
	                    <td><?php echo($center['center_name']); ?></td>
	                    <td><?php echo($center['from_time'].' to '.$center['to_time']); ?></td>
	                    <td><?php echo($center['date']); ?></td>
	                    <td><a href="http://www.google.com/maps/place/<?php echo($center['latitude']); ?>,<?php echo($center['longitude']); ?>"><?php echo($center['latitude'].'/'.$center['longitude']); ?></a></td>
	           
	                  </tr>
	                <?php endforeach; ?> 
	        </tbody>
	      </table>	       
        </div>
      </div>
      
    </div>
  </div>



    <div class="table-container mt-3">
      <table class="table table-bordered" id="table_head">
        <thead>
          <tr>
            <th>Center Name</th>
            <th>Working Hour</th>
            <th>Date</th>
            <th>Location</th>
            <th>Available Dosage</th>
            <th>Apply</th>

          
          </tr>
        </thead>
        <tbody  id="table_body">


        </tbody>
      </table>
      
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>

      function search_by_name() {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("search_name");
        filter = input.value.toUpperCase();
        table = document.getElementById("table_head");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
          td = tr[i].getElementsByTagName("td")[0];
          if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
              tr[i].style.display = "";
            } else {
              tr[i].style.display = "none";
            }
          }       
        }
      }
      const datePicker = document.getElementById('datePicker');


      const currentDate = new Date().toISOString().split('T')[0];


      datePicker.value = currentDate;
      datePicker.min = currentDate;

      document.getElementById('datePicker').addEventListener('change', function() {

        fetchData(getSelectedDate());
      });



        function fetchData(date) {
          const resultContainer = document.getElementById('table_body');


    
            fetch(`data.php?date=${date}`)
            .then(response => response.json())
            .then(data => {

                resultContainer.innerHTML = '';

                if (data.length > 0) {
                    data.forEach(item => {
                        const newRow = document.createElement('tr');

                        newRow.innerHTML = `
                            <td>${item.center_name}</td>
                            <td>${item.from_time} - ${item.to_time}</td>
                            <td>${item.date}</td>
                            <td><a href="http://www.google.com/maps/place/${item.latitude},${item.longitude}">${item.latitude}+'/'+${item.longitude}</a></td>
                            <td>${item.dosage_balance}</td>
                            <td>${item.dosage_balance > 0 ? `<a class="btn btn-success" href="apply_center.php?center_id=${item.center_id}&date=${item.date}&id=${item.id}">Apply</a>` : ''}</td>

                        `;


                        resultContainer.appendChild(newRow);
                    });
                } else {

                    const newRow = document.createElement('tr');
                    newRow.innerHTML = '<td colspan="7">No results found.</td>';
                    resultContainer.appendChild(newRow);
                }
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
        }
        fetchData(getSelectedDate());
        function getSelectedDate() {
          const selectElement = document.getElementById('datePicker');
          return selectElement.value;
        }
   
    </script>
</body>


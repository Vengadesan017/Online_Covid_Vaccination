<?php 
	session_start();
	require "./../config.php";
	try{
	

	if(isset($_GET['center_id']) && isset($_GET['center_id'])){
		$center_id=$_GET['center_id'];
		$date=$_GET['date'];
		$user_id=$_SESSION['user_id'];
		$id=$_GET['id'];



		$create = $conn->prepare("INSERT INTO vaccination_booking( user_id, date, center_id) VALUES (?,?, ?)");
	    $create->execute([$user_id,$date,$center_id]);

	    $msg='Your slot was Successfully Booked. ';


	   	$create = $conn->prepare("UPDATE vaccination_slot SET dosage_balance = dosage_balance - 1 where id=?;
");
	    $create->execute([$id]);


		if ($msg) {
			$_SESSION['msg']=$msg;
		} 

	}
	 header("location: index.php");
	}
	catch(PDOException $e){
    $_SESSION['error']="Can't Book the slot because  ".$e->getMessage();
    header("location: index.php");
	}

	

 ?>
<?php


$host="localhost";
$db="Covid_Vaccine";
$user="root";
$pass="";

try{

	$conn=new PDO("mysql:host=$host;dbname=$db;",$user,$pass);
	
	if (!$conn){echo "connection faild";}
	}
catch(PDOException $e){
    echo $e->getMessage();
}
?>
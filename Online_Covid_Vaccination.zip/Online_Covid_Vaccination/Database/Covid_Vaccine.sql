-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 21, 2023 at 01:18 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Covid_Vaccine`
--

-- --------------------------------------------------------

--
-- Table structure for table `Centers`
--

CREATE TABLE `Centers` (
  `center_id` int(11) NOT NULL,
  `center_name` varchar(100) NOT NULL,
  `latitude` float NOT NULL,
  `longitude` float NOT NULL,
  `from_time` time NOT NULL,
  `to_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Centers`
--

INSERT INTO `Centers` (`center_id`, `center_name`, `latitude`, `longitude`, `from_time`, `to_time`) VALUES
(1, 'chennai', 13.0674, 80.2376, '09:30:00', '18:01:00');

-- --------------------------------------------------------

--
-- Table structure for table `login_type`
--

CREATE TABLE `login_type` (
  `login_id` int(11) NOT NULL,
  `login_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_type`
--

INSERT INTO `login_type` (`login_id`, `login_name`) VALUES
(1, 'User'),
(2, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`user_id`, `username`, `password`, `email`, `login_id`) VALUES
(1, 'admin', '$2y$10$GmVj5/C1neJdQyTMzBk6bOGCMa1VyNCXsaKR/HGvGg67lZlCAo4Ru', 'x@gmail.com', 2),

(2, 'user', '$2y$10$DJ0fSTl1TYKQLfuewqQT5.fjiwg3XQNzXCiSOc2kIo4Hk3VW6xS3.', 'user@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vaccination_booking`
--

CREATE TABLE `vaccination_booking` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `center_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vaccination_booking`
--


-- --------------------------------------------------------

--
-- Table structure for table `vaccination_slot`
--

CREATE TABLE `vaccination_slot` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `center_id` int(11) NOT NULL,
  `dosage_balance` int(11) NOT NULL DEFAULT 10
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--

--
--
-- Indexes for dumped tables
--

--
-- Indexes for table `Centers`
--
ALTER TABLE `Centers`
  ADD PRIMARY KEY (`center_id`);

--
-- Indexes for table `login_type`
--
ALTER TABLE `login_type`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `id` (`user_id`);

--
-- Indexes for table `vaccination_booking`
--
ALTER TABLE `vaccination_booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vaccination_slot`
--
ALTER TABLE `vaccination_slot`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Centers`
--
ALTER TABLE `Centers`
  MODIFY `center_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vaccination_booking`
--
ALTER TABLE `vaccination_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vaccination_slot`
--
ALTER TABLE `vaccination_slot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
session_start();
?>

<?php
include_once "config.php";
try {
    if (isset($_POST["login"])) {
        if ($_POST["username"] == "" || $_POST["password"] == "") {
            echo '<script type="text/javascript">alert("Enter all details");</script>';
        } else {
            $username = $_POST["username"];
            $password = $_POST["password"];

            $login = $conn->prepare("SELECT user_id, username, password, email, login_id FROM Users WHERE  username=?");
            $login->execute([$username]);
            $data = $login->fetch(PDO::FETCH_ASSOC);

            if ($login->rowCount() > 0 && ($data['username'] === $username)) {
                if (password_verify($password, $data["password"])) {
                    $login_type = $data["login_id"];

                    switch ($login_type) {
                        case 1:
                            $_SESSION["user_id"] = $data["user_id"];
                            $_SESSION["username"] = $data["username"];
                            $_SESSION['start'] = time();
                            $_SESSION['expire'] = $_SESSION['start'] + (30 * 60); //session work for 30 minutes
                            header("location: ./User/index.php");
                            break;
                        case 2:
                            $_SESSION["admin"] = $data["username"];
                            $_SESSION["user_id"] = $data["user_id"];
                            $_SESSION['start'] = time();
                            $_SESSION['expire'] = $_SESSION['start'] + (30 * 60); //session work for 30 minutes
                            header("location: ./Admin/index.php");
                            break;
                        default:
                            $_SESSION['error'] = "User cannot be mapped with a role!";
                            header("Location: index.php");
                    }
                } else {
                    $_SESSION['error'] = "Invalid password";
                    header("Location: index.php");
                }
            } else {
                $_SESSION['error'] = "Invalid username";
                header("Location: index.php");
            }
        }
    }


    // header("Location: index.php");
} catch (PDOException $e) {
    $_SESSION['error'] = $e->getMessage();
    header("Location: index.php");
}

$conn = null;
?>

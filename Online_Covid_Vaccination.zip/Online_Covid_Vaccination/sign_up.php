<?php
    
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Login Page</title>
  <style>
    body {

      background-color: #f2f2f2;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .container {
      width: 300px;
      padding: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    h2 {
      text-align: center;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
    }

    .form-group input {
      width: 100%;
      padding: 8px;
      font-size: 16px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }


    .form-group .sign_up-button {
      width: 100%;
      padding: 10px;
      font-size: 16px;
      font-weight: bold;
      color: #fff;
      background-color: #4CAF50;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .form-group .sign_up-button:hover {
      background-color: #45a049;
    }
  .alert {
    position: relative;
    padding: 15px;
    margin-bottom: 20px;
    border: 1px solid transparent;
    border-radius: 4px;
  }

  .alert-danger {
    color: #721c24;
    background-color: #f8d7da;
    border-color: #f5c6cb;
    text-align: center;

  }
  .alert-success {
    background-color: #d4edda;
    color: #155724;
    border-color:#c3e6cb;
    text-align: center;

  }
  .close {
    position: absolute;
    top: 0;
    right: 0;
    padding: 15px;
    color: inherit;
  cursor: pointer;
}

  </style>
</head>
<body>
  <div class="container">
    <h2>Sign up as new User</h2>
    <?php
            if (isset($_SESSION['error'])) {
                
echo " <div class='alert alert-danger alert-dismissible text-center'>
                    ".$_SESSION['error']."<div class='close'>&times;</div>
                </div>
            ";
                unset($_SESSION['error']);
            }
            elseif (isset($_SESSION["username"])) {
                header("location: logout.php");
            }


    ?>
    <form name="sign_up" method="POST" action="new_user.php">
      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
      </div>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
      </div>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
      </div>


      <div class="form-group">
        <input type="submit" class="sign_up-button" value="Sign up" name="sign_up">
      </div>

    </form>
  </div>
    <script type="text/javascript">
  document.addEventListener("DOMContentLoaded", function() {
  var closeButtons = document.querySelectorAll(".alert.alert-dismissible .close");
  for (var i = 0; i < closeButtons.length; i++) {
    closeButtons[i].addEventListener("click", function() {
      var alertDiv = this.parentElement;
      alertDiv.style.display = "none";
    });
  }
});
    </script>
</body>
</html>

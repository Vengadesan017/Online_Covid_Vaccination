<?php
  
    include_once "data.php";

    if (isset($_SESSION['admin']) && isset($_SESSION['user_id'])){
      
      $now = time();
        
          if($now > $_SESSION['expire']) {
              header("Location: ./../logout.php");  
          }
    }
    else {
      header("location: ./../index.php");
    }   

?>
<!DOCTYPE html>
<html>
<head>
  <title>Covid vaccination booking</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Covid vaccination booking</a>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Center</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="dosage.php">Dosage</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo($_SESSION['admin']); ?>
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="./../logout.php">Logout</a>
          </div>
        </li>
      </ul>
    </div>
  </nav>
  <?php
    if (isset($_SESSION['error'])) {
      echo " <div class='alert alert-danger alert-dismissible text-center mt-3'>
              ".$_SESSION['error']."<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a></div>
      ";
      unset($_SESSION['error']);
    }
    if (isset($_SESSION['msg'])) {
      echo " <div class='alert alert-success alert-dismissible text-center mt-3'>
              ".$_SESSION['msg']."<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a></div>";
      unset($_SESSION['msg']);
    }
  ?>
  <div class="container">
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">

                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Search Center:</span>
                    </div>
                    <input type="search" class="form-control" placeholder="Search for..." onkeyup="search_by_name()" id="search_name">

                </div>
            </div>
            <div class="col-md-6">

                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Select Date:</span>
                    </div>
                    <input type="date" class="form-control" id='datePicker'>
                </div>
            </div>
        </div>
    </div>
    <div class="table-container mt-3">
      <table class="table table-bordered" id="table_head">
        <thead>
          <tr>
            <th>Center Name</th>
            <th>Working Hour</th>
            <th>Location</th>  
            <th>Date</th> 
            <th>Total Dosage</th>           
            <th>Booked Dosage</th>                          
            <th>Available Dosage</th>
          </tr>
        </thead>
        <tbody id="table_body">
          <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>    
            <td></td>                        
          </tr>
        </tbody>
      </table>
      
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
      function search_by_name() {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("search_name");
        filter = input.value.toUpperCase();
        table = document.getElementById("table_head");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
          td = tr[i].getElementsByTagName("td")[0];
          if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
              tr[i].style.display = "";
            } else {
              tr[i].style.display = "none";
            }
          }       
        }
      }
      const datePicker = document.getElementById('datePicker');


      const currentDate = new Date().toISOString().split('T')[0];


      datePicker.value = currentDate;
      datePicker.min = currentDate;

      document.getElementById('datePicker').addEventListener('change', function() {

        fetchData(getSelectedDate());
      });



        function fetchData(date) {
          const resultContainer = document.getElementById('table_body');


    
            fetch(`data.php?date=${date}`)
            .then(response => response.json())
            .then(data => {

                resultContainer.innerHTML = '';

                if (data.length > 0) {
                    data.forEach(item => {
                        const newRow = document.createElement('tr');

                        newRow.innerHTML = `
                            <td>${item.center_name}</td>
                            <td>${item.from_time} - ${item.to_time}</td>
                            <td><a href="http://www.google.com/maps/place/${item.latitude},${item.longitude}">${item.latitude}+'/'+${item.longitude}</a></td>
                            <td>${item.date}</td>
                            <td>10</td>
                            <td>${10 - item.dosage_balance}</td>
                            <td>${item.dosage_balance}</td>
                        `;

                        resultContainer.appendChild(newRow);
                    });
                } else {

                    const newRow = document.createElement('tr');
                    newRow.innerHTML = '<td colspan="7">No results found.</td>';
                    resultContainer.appendChild(newRow);
                }
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
        }
        fetchData(getSelectedDate());
        function getSelectedDate() {
          const selectElement = document.getElementById('datePicker');
          return selectElement.value;
        }
   
    </script>
</body>


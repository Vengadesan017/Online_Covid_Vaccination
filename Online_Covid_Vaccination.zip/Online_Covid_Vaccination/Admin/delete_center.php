<?php 
	require "./../config.php";
	session_start();
	try{
	

	if(isset($_GET['center_id'])){
		$center_id=$_GET['center_id'];
		$error=0;		

		$create = $conn->prepare("DELETE FROM Centers WHERE center_id=?");

		$create->execute([
		    $center_id
		]);


		$_SESSION['msg']='The Selected Center was Successfully Deleted. ';




	}
	header("location: index.php");

	}
	catch(PDOException $e){
    $_SESSION['error']="Can't Delete Center because  ".$e->getMessage();
    header("location: index.php");
	}



 ?>
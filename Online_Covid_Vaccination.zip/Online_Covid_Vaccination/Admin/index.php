<?php
  
   
    include_once "data.php";
  if (isset($_SESSION['admin']) && isset($_SESSION['user_id'])){
    
    $now = time();
      
        if($now > $_SESSION['expire']) {
            header("Location: ./../logout.php");  
        }
  }
  else {
    header("location: ./../index.php");
  }   
  $centers=display_center();

?>
<!DOCTYPE html>
<html>
<head>
  <title>Covid vaccination booking</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Covid vaccination booking</a>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link active" href="index.php">Centers</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="dosage.php">Dosage</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo($_SESSION['admin']); ?>
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="./../logout.php">Logout</a>
          </div>
        </li>
      </ul>
    </div>
  </nav>
  <?php
    if (isset($_SESSION['error'])) {
      echo " <div class='alert alert-danger alert-dismissible text-center mt-3'>
              ".$_SESSION['error']."<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a></div>
      ";
      unset($_SESSION['error']);
    }
    if (isset($_SESSION['msg'])) {
      echo " <div class='alert alert-success alert-dismissible text-center mt-3'>
              ".$_SESSION['msg']."<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a></div>";
      unset($_SESSION['msg']);
    }
  ?>

  <div class="container">
    <button class="btn btn-primary btn-add mt-3" data-toggle="modal" data-target="#new_center">New Center</button>



  <div class="modal fade" id="new_center" role="dialog">
    <div class="modal-dialog">
    

      <div class="modal-content">
        <div class="modal-header">
          <h3>Create New Center</h3>
          <button type="button" class="close" data-dismiss="modal">&times;</button>

        </div>
        <div class="modal-body">
          <form action="data.php" method="POST" name="createCenter">
            <div class="form-group">
              <label for="centerName">Center Name:</label>
              <input type="text" class="form-control" id="centerName" name="centerName" placeholder="Enter center name">
            </div>
            <div class="form-group">
              <label for="latitude">Latitude:</label>
              <input type="text" class="form-control" id="latitude" name="latitude" placeholder="Enter latitude">
            </div>
            <div class="form-group">
              <label for="longitude">Longitude:</label>
              <input type="text" class="form-control" id="longitude" name="longitude" placeholder="Enter longitude">
            </div>
            <div class="form-group">
              <label for="startTime">Starting Time:</label>
              <input type="time" class="form-control" id="startTime" name="startTime">
            </div>
            <div class="form-group">
              <label for="endTime">Ending Time:</label>
              <input type="time" class="form-control" id="endTime" name="endTime">
            </div>
            <button type="submit" class="btn btn-primary" name="createCenter">Submit</button>
          </form>         
        </div>
      </div>
      
    </div>
  </div>



    <div class="table-container mt-3">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Center Name</th>
            <th>Working Hour</th>
            <th>Location</th>                            
            <th>Action</th>

          
          </tr>
        </thead>
        <tbody>
                 <?php foreach ($centers as $center): ?>
                  <tr>
                    <td><?php echo($center['center_name']); ?></td>
                    <td><?php echo($center['from_time'].' to '.$center['to_time']); ?></td>
                    <td><a href="http://www.google.com/maps/place/<?php echo($center['latitude']); ?>,<?php echo($center['longitude']); ?>"><?php echo($center['latitude'].'/'.$center['longitude']); ?></a></td>
                    <td><a class='btn btn-danger 'href="delete_center.php?center_id=<?php echo($center['center_id']); ?>">Delete</a></td>
           
                  </tr>
                <?php endforeach; ?> 
        </tbody>
      </table>
      
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>


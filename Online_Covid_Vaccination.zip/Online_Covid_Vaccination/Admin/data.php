<?php
	include_once "./../config.php";
   	session_start();
	


	function display_center(){
		global $conn;
		$fetch_query="SELECT center_id, center_name, latitude, longitude, from_time, to_time FROM Centers";
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql=$conn->prepare($fetch_query);
		$sql->execute();
		$x= $sql->setFetchMode(PDO::FETCH_ASSOC);
		$centers=$sql->fetchAll();

		return $centers;

	}

	function dosage_balance($id, $date) {
	    global $conn;
	    $fetch_query = "SELECT dosage_balance FROM vaccination_slot WHERE date=? AND center_id=?";
	    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	    $sql = $conn->prepare($fetch_query);
	    $sql->execute([$date, $id]);
	    $row_count = $sql->rowCount();

	    return $row_count > 0; 
	}



	function check_slot($date) {
	    global $conn;
	    $fetch_query = "SELECT center_id, center_name FROM Centers";
	    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	    $sql = $conn->prepare($fetch_query);
	    $sql->execute();
	    $slots = $sql->fetchAll();

	    foreach ($slots as $key => $value) {
	        if (!dosage_balance($value['center_id'], $date)) {
	            $insert = $conn->prepare("INSERT INTO vaccination_slot (date, center_id) VALUES (?,?)");
	            $insert->execute([$date, $value['center_id']]);
	        }
	    }
	}





    if(isset($_POST['createCenter'])){
        $centerName = $_POST['centerName'];
        $latitude = floatval($_POST['latitude']);
        $longitude = floatval($_POST['longitude']);
        $startTime = $_POST['startTime'];
        $endTime = $_POST['endTime'];
            
        $decodedStartTime = urldecode($startTime);
        $startTime = date("H:i:s", strtotime($decodedStartTime));

        $decodedEndTime = urldecode($endTime);
        $endTime = date("H:i:s", strtotime($decodedEndTime));

        $create = $conn->prepare("INSERT INTO Centers (center_name, latitude, longitude, from_time, to_time) VALUES (?,?,?,?,?)");

		try {
		    $create->execute([
		        $centerName,
		        $latitude,
		        $longitude,
		        $startTime,
		        $endTime
		    ]);

		} catch (PDOException $e) {
		    $_SESSION['error'] = $centerName.'Error: ' . $e->getMessage();
		    header("location: index.php");
		}

        $_SESSION['msg'] = 'The New Center ' . $centerName . ' was Created Successfully';
        header("location: index.php");
    }

	if(isset($_GET['date'])){

		$date=$_GET['date'];

		check_slot($date);

		$sql = "SELECT c.center_id, c.center_name, c.latitude, c.longitude, c.from_time, c.to_time,vs.dosage_balance,vs.date FROM Centers c LEFT JOIN vaccination_slot vs on c.center_id=vs.center_id WHERE vs.date=?";
		$stmt = $conn->prepare($sql);
		try {
		$stmt->execute([$date]);
		$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
		} catch (PDOException $e) {
		    $_SESSION['error']=$e->getMessage();
		}
		

		header('Content-Type: application/json');
		echo json_encode($data);		
	}

?>


